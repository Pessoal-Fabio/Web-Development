// alert("Hello World")

//DECLARAÇÃO E VARIAVEIS 

var nome ="Fiap";
console.log(Nome)